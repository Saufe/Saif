from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivymd.app import MDApp
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import webbrowser

class LoginScreen(Screen):
    pass

class RegisterScreen(Screen):
    pass

class MainScreen(Screen):
    pass

class SettingsScreen(Screen):
    pass

class FootballApp(MDApp):
    def build(self):
        self.screen_manager = ScreenManager()
        self.screen_manager.add_widget(LoginScreen(name="login"))
        self.screen_manager.add_widget(RegisterScreen(name="register"))
        self.screen_manager.add_widget(MainScreen(name="main"))
        self.screen_manager.add_widget(SettingsScreen(name="settings"))

        # عرض النافذة عند تشغيل التطبيق
        self.show_instagram_popup()

        return self.screen_manager

    def show_instagram_popup(self):
        layout = BoxLayout(orientation='vertical', spacing=10, padding=10)

        message = Label(text="🌟 تابعنا على Instagram للبقاء على اطلاع!", size_hint_y=None, height=50)
        follow_button = Button(text="📸 متابعة الآن", size_hint_y=None, height=40)
        close_button = Button(text="❌ إغلاق", size_hint_y=None, height=40)

        follow_button.bind(on_press=lambda x: webbrowser.open("https://www.instagram.com/s25_0?igsh=MWllbmlueTU5eDlocA=="))
        close_button.bind(on_press=lambda x: popup.dismiss())

        layout.add_widget(message)
        layout.add_widget(follow_button)
        layout.add_widget(close_button)

        popup = Popup(title="تابعنا على Instagram", content=layout, size_hint=(0.8, 0.4))
        popup.open()

if __name__ == "__main__":
    FootballApp().run()
