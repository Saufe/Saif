LANGUAGES = {
    "ar": {
        "settings": "⚙️ الإعدادات",
        "theme": "🌙 الوضع الليلي",
        "save": "💾 حفظ الإعدادات",
        "login": "🔑 تسجيل الدخول",
        "register": "📝 إنشاء حساب جديد",
        "update_profile": "📝 تحديث البيانات",
        "change_password": "🔒 تغيير كلمة المرور",
        "favorite_teams": "⭐ الفرق المفضلة",
    },
    "en": {
        "settings": "⚙️ Settings",
        "theme": "🌙 Dark Mode",
        "save": "💾 Save Settings",
        "login": "🔑 Login",
        "register": "📝 Register",
        "update_profile": "📝 Update Profile",
        "change_password": "🔒 Change Password",
        "favorite_teams": "⭐ Favorite Teams",
    }
}
